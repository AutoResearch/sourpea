# SourPea

inspired by <https://github.com/sweetpea-org/>
functions to check counterbalancing of design

*heavily under development*